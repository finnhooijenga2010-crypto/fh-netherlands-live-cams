# F.H. Netherlands Live Cams — Replit PWA

A mobile-first Progressive Web App for discovering links to publicly published webcam pages. Starts with Friesland and includes nationwide directories.

## Run on Replit from an iPhone

1. In Safari, open https://replit.com/ and sign in or create an account.
2. Create a new Repl using the **HTML, CSS, JS** template (sometimes called a Static website).
3. Open the Files panel.
4. Replace the contents of `index.html` and `style.css`/`styles.css` as appropriate. Create the files listed below if they do not exist.
5. Add `app.js`, `manifest.webmanifest`, `sw.js`, and `icon.svg`.
6. Make sure all files are in the project root, beside `index.html`.
7. Tap **Run**. Replit will show a preview URL ending in `replit.app`.
8. Open that URL in Safari. Test search, filters and favourites.
9. In Safari, tap **Share → Add to Home Screen**. If offered, enable **Open as Web App**, then tap Add.

## Files

- `index.html` — app structure
- `styles.css` — responsive dark crimson design
- `app.js` — camera directory, search, filters, favourites and install prompt
- `manifest.webmanifest` — PWA metadata
- `sw.js` — caches the app shell for repeat/offline opening
- `icon.svg` — app icon

## Camera sources and limitations

The app links to public publisher pages and directories; it does not claim that every listed city has an individual working stream. Check each publisher's current page, terms and permissions. The app deliberately does not extract hidden stream URLs, bypass access restrictions, scan for exposed cameras or record video.

Starter sources:
- https://bekijkhet.nu/cams-fr.html
- https://www.rwsverkeersinfo.nl/cameras/
- https://heelhollandkijkt.nl/

## Editing the directory

Open `app.js` and add another object to the `cameras` array. Use a publisher-approved public page URL. Keep the unique `id`, `name`, `place`, `region`, `category`, `icon`, `description`, `source`, and `url` fields.

## Privacy

No account, analytics, location access, camera access or backend is used. Favourite IDs are stored locally in the browser using localStorage. External links open at their publishers, whose privacy policies apply.

## Notes

- A PWA must be served over HTTPS for service workers and installation support. Replit's published web URL uses HTTPS.
- iOS Safari's **Add to Home Screen** is the reliable manual installation route. Browser install prompts are not consistently supported on iOS.
- The app is a directory of links, not a video proxy or CCTV monitoring system.
