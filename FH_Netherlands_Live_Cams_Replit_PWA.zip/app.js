const cameras = [
 {id:"leeuwarden",name:"Leeuwarden webcams",place:"Leeuwarden",region:"Friesland",category:"City",icon:"⌂",description:"Browse publicly listed city-view webcams for Leeuwarden. Individual feeds are hosted by their publishers.",source:"Bekijkhet.nu · Friesland",url:"https://bekijkhet.nu/cams-fr.html"},
 {id:"dokkum",name:"Dokkum webcams",place:"Dokkum",region:"Friesland",category:"City",icon:"⌂",description:"Find public town and canal-view webcam listings for Dokkum.",source:"Bekijkhet.nu · Friesland",url:"https://bekijkhet.nu/cams-fr.html"},
 {id:"drachten",name:"Drachten webcams",place:"Drachten",region:"Friesland",category:"City",icon:"⌂",description:"Browse public webcam directory listings around Drachten and the surrounding area.",source:"Bekijkhet.nu · Friesland",url:"https://bekijkhet.nu/cams-fr.html"},
 {id:"harlingen",name:"Harlingen harbour webcams",place:"Harlingen",region:"Friesland",category:"Harbour",icon:"⚓",description:"Look for public harbour and waterfront views published for Harlingen.",source:"Bekijkhet.nu · Friesland",url:"https://bekijkhet.nu/cams-fr.html"},
 {id:"sneek",name:"Sneek webcams",place:"Sneek",region:"Friesland",category:"Harbour",icon:"⚓",description:"Browse public webcam listings around Sneek, its waterways and marina.",source:"Bekijkhet.nu · Friesland",url:"https://bekijkhet.nu/cams-fr.html"},
 {id:"fr-directory",name:"All Friesland webcams",place:"Friesland",region:"Friesland",category:"Nature",icon:"✳",description:"Open the regional directory to explore more public webcams across the province.",source:"Bekijkhet.nu",url:"https://bekijkhet.nu/cams-fr.html"},
 {id:"rws",name:"Rijkswaterstaat traffic cameras",place:"Across the Netherlands",region:"Nationwide",category:"Traffic",icon:"↗",description:"Official traffic-camera overview. Check the publisher for current availability and viewing conditions.",source:"Rijkswaterstaat",url:"https://www.rwsverkeersinfo.nl/cameras/"},
 {id:"heel-holland",name:"Netherlands webcam directory",place:"Across the Netherlands",region:"Nationwide",category:"City",icon:"⌂",description:"Explore a directory of webcams published for public viewing around the country.",source:"Heel Holland Kijkt",url:"https://heelhollandkijkt.nl/"}
];

const $ = id => document.getElementById(id);
let region = "All", category = "All", onlyFavourites = false;
let favourites = new Set(JSON.parse(localStorage.getItem("fh-favourites") || "[]"));

function render() {
 const query = $("searchInput").value.trim().toLocaleLowerCase("nl");
 const filtered = cameras.filter(c =>
   (region === "All" || c.region === region) &&
   (category === "All" || c.category === category) &&
   (!onlyFavourites || favourites.has(c.id)) &&
   (!query || `${c.name} ${c.place} ${c.region} ${c.category} ${c.description}`.toLocaleLowerCase("nl").includes(query))
 );
 $("cameraCount").textContent = cameras.length;
 $("resultsTitle").textContent = onlyFavourites ? "Your favourites" : "Public camera pages";
 $("cameraGrid").innerHTML = filtered.map(c => `
  <article class="camera-card">
   <div class="card-top">
    <div class="category-icon" aria-hidden="true">${c.icon}</div>
    <button class="favourite ${favourites.has(c.id) ? "saved" : ""}" data-favourite="${c.id}" aria-label="${favourites.has(c.id) ? "Remove" : "Add"} ${c.name} ${favourites.has(c.id) ? "from" : "to"} favourites" aria-pressed="${favourites.has(c.id)}">${favourites.has(c.id) ? "♥" : "♡"}</button>
   </div>
   <h3>${escapeHTML(c.name)}</h3>
   <div class="place">${escapeHTML(c.place)} · ${escapeHTML(c.region)}</div>
   <p class="description">${escapeHTML(c.description)}</p>
   <div class="card-bottom"><span class="source">${escapeHTML(c.source)}</span><a class="open-link" href="${c.url}" target="_blank" rel="noopener noreferrer">OPEN SOURCE ↗</a></div>
  </article>`).join("");
 $("emptyState").hidden = filtered.length !== 0;
 $("cameraGrid").hidden = filtered.length === 0;
 document.querySelectorAll("[data-favourite]").forEach(button => button.addEventListener("click", () => toggleFavourite(button.dataset.favourite)));
}
function escapeHTML(value) {
 return value.replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function toggleFavourite(id) {
 favourites.has(id) ? favourites.delete(id) : favourites.add(id);
 localStorage.setItem("fh-favourites", JSON.stringify([...favourites]));
 render();
}
document.querySelectorAll("[data-region]").forEach(button => button.addEventListener("click", () => {
 region = button.dataset.region;
 document.querySelectorAll("[data-region]").forEach(b => b.classList.toggle("active", b === button));
 render();
}));
document.querySelectorAll("[data-category]").forEach(button => button.addEventListener("click", () => {
 category = button.dataset.category;
 document.querySelectorAll("[data-category]").forEach(b => b.classList.toggle("active", b === button));
 render();
}));
$("searchInput").addEventListener("input", render);
$("favouritesToggle").addEventListener("click", () => {
 onlyFavourites = !onlyFavourites;
 $("favouritesToggle").classList.toggle("active", onlyFavourites);
 $("favouritesToggle").setAttribute("aria-pressed", String(onlyFavourites));
 $("favouritesToggle").textContent = onlyFavourites ? "♥ Show all" : "♡ Favourites";
 render();
});
$("clearFilters").addEventListener("click", () => {
 $("searchInput").value = ""; region = "All"; category = "All"; onlyFavourites = false;
 document.querySelectorAll(".chip").forEach(b => b.classList.toggle("active", b.dataset.region === "All" || b.dataset.category === "All"));
 $("favouritesToggle").textContent = "♡ Favourites";
 $("favouritesToggle").setAttribute("aria-pressed", "false");
 render();
});
let installPrompt;
window.addEventListener("beforeinstallprompt", event => {
 event.preventDefault(); installPrompt = event; $("installButton").hidden = false;
});
$("installButton").addEventListener("click", async () => {
 if (!installPrompt) return;
 installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; $("installButton").hidden = true;
});
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(console.error));
render();
